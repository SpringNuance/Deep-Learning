Overview
========

Welcome. We're thrilled you want to contribute to nbgrader.

This guide gives an overview of various parts of the project and what our
expectations are for contributions.

In general, the guidelines for opening issues, submitting PRs, code style,
testing, and documentation, are the same as the `IPython contribution
guidelines <https://github.com/ipython/ipython/blob/master/CONTRIBUTING.md>`_.
