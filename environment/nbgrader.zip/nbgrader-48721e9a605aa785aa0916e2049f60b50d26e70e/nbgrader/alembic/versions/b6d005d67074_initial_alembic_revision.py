"""Initial alembic revision

Revision ID: b6d005d67074
Revises: 
Create Date: 2017-06-01 16:05:35.868678

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b6d005d67074'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
