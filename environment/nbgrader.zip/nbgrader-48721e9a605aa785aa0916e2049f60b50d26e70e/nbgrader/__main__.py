from .apps.nbgraderapp import main
main()
