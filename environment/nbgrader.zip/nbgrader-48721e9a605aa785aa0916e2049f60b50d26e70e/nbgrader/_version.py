version_info = (0, 6, 0, 'dev')
__version__ = '.'.join(map(str, version_info))