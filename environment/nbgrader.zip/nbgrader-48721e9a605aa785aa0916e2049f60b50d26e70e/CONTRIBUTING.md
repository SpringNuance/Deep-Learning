# Contributing to nbgrader

We're thrilled you want to contribute to nbgrader.

The [developer documentation](https://nbgrader.readthedocs.io/en/latest/contributor_guide/overview.html)
gives an overview of how various parts of the project work and what our
expectations are for contributions.
